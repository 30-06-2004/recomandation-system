<!--
Copyright (c) Recommenders contributors.
Licensed under the MIT License.
-->

# Recommendation System Scenarios

On this section there is listed a number of business scenarios that are common in Recommendation Systems.

The list of scenarios are:

* [Ads](ads)
* [Food and restaurants](food_and_restaurants)
* [Gaming](gaming)
* [News and Documents](news)
* [Retail](retail)
* [Travel](travel)




