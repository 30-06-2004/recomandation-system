# Copyright (c) Recommenders contributors.
# Licensed under the MIT License.

installed = 1
